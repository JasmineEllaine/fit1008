def hash(input_string):
    return ord(input_string[0]) % 11